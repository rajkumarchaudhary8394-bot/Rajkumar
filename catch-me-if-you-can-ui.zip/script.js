const btnYes = document.getElementById('btn-yes');
const btnNo = document.getElementById('btn-no');
const card1 = document.getElementById('card1');
const card2 = document.getElementById('card2');
const music = document.getElementById('bgMusic');

// Create highly vibrant confetti background
function createRain() {
  const drop = document.createElement('div');
  drop.classList.add('rain-drop');
  
  const leftPos = Math.random() * window.innerWidth * 1.5 - window.innerWidth * 0.25;
  const duration = 1.5 + Math.random() * 2;
  const opacity = 0.6 + Math.random() * 0.4;
  const size = 6 + Math.random() * 10;
  const hue = Math.random() * 360;

  drop.style.left = `${leftPos}px`;
  drop.style.top = `-50px`;
  drop.style.animationDuration = `${duration}s`;
  drop.style.opacity = opacity;
  
  // Give confetti random shapes (squares or circles)
  if (Math.random() > 0.5) {
    drop.style.borderRadius = '50%';
  }
  
  drop.style.width = `${size}px`;
  drop.style.height = `${size}px`;
  drop.style.background = `hsl(${hue}, 100%, 65%)`;
  drop.style.boxShadow = `0 0 8px hsl(${hue}, 100%, 65%)`;

  document.body.appendChild(drop);

  setTimeout(() => {
    drop.remove();
  }, duration * 1000);
}

// Continuous confetti shower
setInterval(createRain, 40);

let hasCalledPlay = false;
let attempts = 0;
let isMoving = false;

music.loop = true;

music.addEventListener("ended", () => {
   music.currentTime = 0;
   const playPromise = music.play();
   if (playPromise !== undefined) {
     playPromise.catch(e => console.log("Loop retry failed", e));
   }
});

function moveYesBtn(e) {
  if (e && e.type !== 'mousemove') e.preventDefault();
  
  if (isMoving || attempts >= 10) return;
  isMoving = true;
  attempts++;

  // 1) Slight scale-up effect before moving
  btnYes.style.transition = 'transform 0.1s ease-out';
  btnYes.style.transform = 'scale(1.05)';

  setTimeout(() => {
    if (attempts >= 10) {
      btnYes.classList.remove('crack-1', 'crack-2', 'crack-3', 'crack-4');
      btnYes.classList.add('broken');
      btnYes.style.transform = 'scale(1)';
      btnYes.innerText = "You tried too hard 💔";
      btnYes.disabled = true;
      return; 
    }

    if (attempts === 5) btnYes.classList.add('crack-1');
    else if (attempts === 7) btnYes.classList.add('crack-2');
    else if (attempts === 8) btnYes.classList.add('crack-3');
    else if (attempts === 9) btnYes.classList.add('crack-4');

    const rect = btnYes.getBoundingClientRect();
    let currentX = rect.left;
    let currentY = rect.top;

    // Transition to absolute positioning if not already
    if (btnYes.style.position !== 'fixed') {
      btnYes.style.transition = 'none';
      btnYes.style.position = 'fixed';
      btnYes.style.left = currentX + 'px';
      btnYes.style.top = currentY + 'px';
      void btnYes.offsetWidth; // Force reflow
    }

    // Smooth ease-out for movement (250ms)
    btnYes.style.transition = 'left 0.25s ease-out, top 0.25s ease-out';

    const btnWidth = btnYes.offsetWidth;
    const btnHeight = btnYes.offsetHeight;
    const padding = 16; // minimum padding from edges
    const minX = padding;
    const maxX = window.innerWidth - btnWidth - padding;
    const minY = padding;
    const maxY = window.innerHeight - btnHeight - padding;

    // Card dimensions for avoiding the center
    const cardRect = card1.getBoundingClientRect();
    const cardBox = {
        left: cardRect.left - padding,
        right: cardRect.right + padding,
        top: cardRect.top - padding,
        bottom: cardRect.bottom + padding
    };
    const cardCenterX = cardRect.left + cardRect.width / 2;

    // Move a reasonable distance to escape the 80px hover zone
    let maxDistance = 250;
    let minDistance = 120;
    
    // Random angle strictly restricting downward movement
    // We also split the angle generation to explicitly force the button
    // outward (away from the center of the card) for a playful escape.
    let angle;
    if (currentX + btnWidth / 2 < cardCenterX) {
        // Button is on the Left side. Escape Left & Up.
        // Math.PI to 1.5*Math.PI
        angle = Math.PI + Math.random() * (Math.PI / 2);
    } else {
        // Button is on the Right side. Escape Right & Up.
        // 1.5*Math.PI to 2*Math.PI
        angle = 1.5 * Math.PI + Math.random() * (Math.PI / 2);
    }

    const distance = minDistance + Math.random() * (maxDistance - minDistance);

    let dx = Math.cos(angle) * distance;
    let dy = Math.sin(angle) * distance;

    let newX = currentX + dx;
    let newY = currentY + dy;

    // Bouncing rules: keep it in bounds
    if (newX < minX) newX = currentX + Math.abs(dx * 1.5);
    if (newX > maxX) newX = currentX - Math.abs(dx * 1.5);
    
    // Ensure no downward movement even on bounces
    if (newY < minY) {
       newY = minY; // Cap at the very top
       // Only shift left or right if it's stuck at the top
       newX = newX < window.innerWidth / 2 ? maxX : minX; 
    }

    // Hard guarantee: NEVER MOVE DOWNWARD
    if (newY > currentY) {
        newY = currentY;
    }

    // Card Overlap Prevention
    const overlapsCard = (newX + btnWidth > cardBox.left && newX < cardBox.right && 
                          newY + btnHeight > cardBox.top && newY < cardBox.bottom);
    
    if (overlapsCard) {
        // Can't move down, so we must go UP or to the SIDE
        if (currentY + btnHeight <= cardBox.top) {
            // If it was already above the card, keep it above
            newY = cardBox.top - btnHeight - 10;
        } else {
            // Otherwise shove it to the far left or right
            newX = currentX < cardBox.left ? (cardBox.left - btnWidth - 10) : (cardBox.right + 10);
        }
    }

    // Final clamp
    newX = Math.max(minX, Math.min(maxX, newX));
    newY = Math.max(minY, Math.min(maxY, newY));

    btnYes.style.left = newX + 'px';
    btnYes.style.top = newY + 'px';

    btnYes.style.transform = 'none';

    // Add subtle bounce after movement
    btnYes.animate([
      { transform: 'scale(1) rotate(0deg)' },
      { transform: 'scale(1.08) rotate(3deg)', offset: 0.5 },
      { transform: 'scale(0.97) rotate(-2deg)', offset: 0.8 },
      { transform: 'scale(1) rotate(0deg)' }
    ], { duration: 350, easing: 'ease-out', delay: 150 });
    
    setTimeout(() => {
      isMoving = false;
    }, 250); 
  }, 100); 
}

document.addEventListener('mousemove', (e) => {
    if (attempts >= 10 || isMoving) return;
    const rect = btnYes.getBoundingClientRect();
    const btnCenterX = rect.left + rect.width / 2;
    const btnCenterY = rect.top + rect.height / 2;
    // Check proximity (~80px)
    const distance = Math.hypot(e.clientX - btnCenterX, e.clientY - btnCenterY);
    if (distance < 80) {
        moveYesBtn();
    }
});

btnYes.addEventListener('mouseover', moveYesBtn);
btnYes.addEventListener('touchstart', moveYesBtn, { passive: false });
btnYes.addEventListener('click', moveYesBtn);

function doPlay() {
  if (hasCalledPlay) return;
  hasCalledPlay = true;
  
  music.volume = 0;
  const playPromise = music.play();
  if (playPromise !== undefined) {
    playPromise.then(() => {
      let vol = 0;
      const fadeInterval = setInterval(() => {
        if (vol < 0.3) {
          vol += 0.015;
          music.volume = Math.min(vol, 0.3);
        } else {
          music.volume = 0.3;
          clearInterval(fadeInterval);
        }
      }, 100);
    }).catch(e => {
      console.log("Audio playback was blocked", e);
      hasCalledPlay = false;
      document.addEventListener('click', doPlay, { once: true });
      document.addEventListener('touchstart', doPlay, { once: true });
    });
  }
}

btnNo.addEventListener('click', () => {
  card1.classList.add('slide-out');
  
  doPlay();
  
  setTimeout(() => {
    card1.style.display = 'none';
    
    card2.style.display = 'block';
    void card2.offsetWidth; 
    card2.classList.add('slide-in');
  }, 600);
});
