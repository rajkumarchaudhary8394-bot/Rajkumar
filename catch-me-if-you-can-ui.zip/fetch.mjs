import https from "https";

https.get("https://ibb.co/GQMLhmBr", (res) => {
  let data = "";
  res.on("data", (chunk) => data += chunk);
  res.on("end", () => {
    const match = data.match(/<meta property="og:image" content="([^"]+)"/);
    if (match) {
      console.log(match[1]);
    } else {
      const match2 = data.match(/<img src="(https:\/\/i\.ibb\.co\/[^"]+)"/);
      console.log(match2 ? match2[1] : "not found");
    }
  });
});
